#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
export KUDIBA_BRIDGE_PORT=17842
export KUDIBA_PRINTER_HOST=127.0.0.1
export KUDIBA_PRINTER_PORT=9100
echo "=========================================================="
echo " Kudiba ERP - Agente Local POS para macOS"
echo " Porta: 17842"
echo "=========================================================="
if [ -f "$DIR/kudiba-hardware-bridge" ]; then
    chmod +x "$DIR/kudiba-hardware-bridge"
    "$DIR/kudiba-hardware-bridge"
else
    echo "Executável kudiba-hardware-bridge não encontrado."
fi
