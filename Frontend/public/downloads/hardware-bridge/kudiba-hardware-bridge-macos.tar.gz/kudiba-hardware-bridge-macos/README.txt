KUDIBA ERP - AGENTE LOCAL POS PARA macOS
Versão 0.1.0

1. Abra o Terminal e dê duplo clique em "iniciar-agente.command".
2. Copie o código de 6 caracteres gerado para emparelhar no Kudiba POS.
