@echo off
title Instalar Servico Kudiba Hardware Bridge
echo ==========================================================
echo  Instalador de Servico Windows - Kudiba Hardware Bridge
echo ==========================================================
echo.
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERRO] Execute este script como Administrador (clique direito -> Executar como administrador).
    pause
    exit /b 1
)

set BINPATH=%~dp0kudiba-hardware-bridge.exe
sc create KudibaHardwareBridge binPath= "%BINPATH%" start= auto DisplayName= "Kudiba POS Hardware Bridge"
sc description KudibaHardwareBridge "Servico de integracao de impressoras termicas ESC/POS e gavetas de dinheiro do Kudiba ERP"
sc start KudibaHardwareBridge
echo.
echo Servico KudibaHardwareBridge instalado e iniciado com sucesso!
pause
