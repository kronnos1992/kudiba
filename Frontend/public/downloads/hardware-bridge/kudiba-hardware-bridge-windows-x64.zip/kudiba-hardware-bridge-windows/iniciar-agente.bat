@echo off
title Kudiba ERP - Agente Local POS
echo ==========================================================
echo  Kudiba ERP - Agente de Hardware Local POS v0.1.0
echo  Porta do Agente: 17842
echo  Impressora Termica: 127.0.0.1:9100
echo ==========================================================
echo.
if exist kudiba-hardware-bridge.exe (
    kudiba-hardware-bridge.exe
) else (
    echo [AVISO] Executavel kudiba-hardware-bridge.exe nao encontrado nesta pasta.
    echo Certifique-se de que o ficheiro executavel esta junto deste script.
    pause
)
