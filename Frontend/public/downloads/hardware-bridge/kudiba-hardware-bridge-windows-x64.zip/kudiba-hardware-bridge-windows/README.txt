========================================================================
 KUDIBA ERP - AGENTE LOCAL POS (HARDWARE BRIDGE)
 Versao: 0.1.0 (Windows 10 / 11 / Server - 64 bits)
========================================================================

COMO USAR NO SEU POSTO DE CAIXA:

1. Executar o Agente:
   - Dê um duplo clique em "iniciar-agente.bat" (ou no executavel).
   - Uma janela de terminal abrira e mostrara:
     "emparelhe o terminal no POS com este codigo (valido 5 minutos): [CODIGO]"

2. Emparelhar no Navegador:
   - No Kudiba ERP, abra o modulo POS ("POS / Caixa Rapido").
   - Aceda a aba "Painel" ou ao aviso de agente no topo.
   - Digite o codigo exibido na janela do terminal e clique em "Emparelhar".
   - A confirmacao "Agente local emparelhado com esta empresa" sera exibida.

3. Impressora Termica e Gaveta:
   - O agente comunica com a impressora termica de taloes na porta 9100 (padrao ESC/POS).
   - Emite automaticamente pulsos na porta RJ11/RJ12 para abertura da gaveta de dinheiro.
   - O ficheiro "configuracao.env" permite alterar o IP da impressora de rede.

4. Inicializacao Automatica (Opcional):
   - Para que o agente inicie sozinho com o Windows sem precisar abrir o terminal,
     clique com o botao direito em "instalar-servico-windows.bat" e escolha
     "Executar como Administrador".
========================================================================
