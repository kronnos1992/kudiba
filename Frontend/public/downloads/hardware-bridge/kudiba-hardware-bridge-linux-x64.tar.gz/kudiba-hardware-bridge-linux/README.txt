KUDIBA ERP - AGENTE LOCAL POS (HARDWARE BRIDGE)
Versão: 0.1.0 (Linux x64)

INSTRUÇÕES DE INSTALAÇÃO E EXECUÇÃO:

1. Execução Imediata:
   Abra o terminal nesta pasta e execute:
   ./iniciar-agente.sh

2. Emparelhar com o Kudiba ERP:
   - Ao iniciar, o terminal exibirá um código de 6 caracteres (ex: 7A9B3C).
   - No painel do POS no navegador, introduza o código e clique em 'Emparelhar'.
   - O agente ficará ativo e conectado à sua impressora térmica e gaveta.

3. Executar como Serviço Automático (Opcional):
   sudo cp -r . /opt/kudiba-hardware-bridge/
   sudo cp /opt/kudiba-hardware-bridge/kudiba-hardware-bridge.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable --now kudiba-hardware-bridge
