#!/usr/bin/env bash
# Kudiba ERP - Iniciar Agente Local POS (ESC/POS & Gaveta)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export KUDIBA_BRIDGE_PORT=${KUDIBA_BRIDGE_PORT:-17842}
export KUDIBA_PRINTER_HOST=${KUDIBA_PRINTER_HOST:-127.0.0.1}
export KUDIBA_PRINTER_PORT=${KUDIBA_PRINTER_PORT:-9100}

echo "=========================================================="
echo " Kudiba ERP - Agente de Hardware Local POS v0.1.0"
echo " Porta do Agente: $KUDIBA_BRIDGE_PORT"
echo " Impressora Térmica: $KUDIBA_PRINTER_HOST:$KUDIBA_PRINTER_PORT"
echo "=========================================================="
chmod +x "$DIR/kudiba-hardware-bridge"
"$DIR/kudiba-hardware-bridge"
